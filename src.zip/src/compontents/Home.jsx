function Home() {
    return (
      <div
      style={{
        padding: '40px',
        display: 'flex',
        justifyContent: 'center',
        height: '150vh',
        color:'Green',
      }}
    >
        
       <h1>Home</h1>
      </div>
    );
  }
  
  export default Home;
package in.org.bangles.api.Employee;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;



@Entity
@Table(name = "login")
public class Employee {

	 @Id
	    @Column(name="employee_id", length = 45)
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int employeeid;
	 
	    @Column(name="employee_name", length = 255)
	    private String employeename;
	    
	    @Column(name="email", length = 255)
	    private String email;
	    
	    @Column(name="password", length = 255)
	    private String password;

		public Employee() {
			super();
			// TODO Auto-generated constructor stub
		}

		public int getEmployeeid() {
			return employeeid;
		}

		public void setEmployeeid(int employeeid) {
			this.employeeid = employeeid;
		}

		public String getEmployeename() {
			return employeename;
		}

		public void setEmployeename(String employeename) {
			this.employeename = employeename;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		
		public Employee(int employeeid, String employeename, String email, String password) {
			super();
			this.employeeid = employeeid;
			this.employeename = employeename;
			this.email = email;
			this.password = password;
		}
		

	

	
}

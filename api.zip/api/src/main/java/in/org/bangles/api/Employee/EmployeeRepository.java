package in.org.bangles.api.Employee;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	
	 Optional<Employee> findOneByEmailAndPassword(String email, String password);
	public Employee findByEmail(String email);

}
